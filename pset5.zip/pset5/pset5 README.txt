PSET5: Spell Check Application

Summary:
Implement a spellchecking application.  The program will load a dictionary of words into memory.  It will then parse over a provided text file and check the dictionary in memory to check if any of those words are spelled incorrectly.  Once that is complete it must unload all of the memory allocated for the dictionary as to ensure no memory leaks.    