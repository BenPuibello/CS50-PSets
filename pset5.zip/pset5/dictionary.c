/**
 * Implements a dictionary's functionality.
 */

#include <stdbool.h>
#include <cs50.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "dictionary.h"

//declare my struct and root node globally
/*
typedef struct node
{
    bool is_word;
    struct node* children[27];
                                
}node;
*/
node root;
node* trav = &root; 


//make my key globally available
char key[27] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '\''};
unsigned int wordCounter;



/**
 * Returns true if word is in dictionary else false.
 */
bool check(const char *word)
{
    int n = strlen(word);
    trav = &root;
    
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < 27; ++j)
        {
            if (tolower(word[i]) == key[j])
            {
                if ( (*trav).children[j] == NULL )
                {
                    return false;
                }
                
                else
                {
                    trav = (*trav).children[j];
                }
            }
        }
        
    }
    
    if ( (*trav).is_word == true)
    {
        return true;
    }
    else
    {
        return false;
    }
    
}

/**
 * Loads dictionary into memory. Returns true if successful else false.
 */
bool load(const char *dictionary)
{
    FILE* fp;
    char word[45];
    fp = fopen(dictionary, "r");
    bool _success = true;
    
    if (fp == NULL)
    {
        fprintf(stderr,"Couldn't open dictionary file");
        return false;
    }
    
    while ( !feof(fp))
    {
        //reset trav if need be
        trav = &root;
        if (fgets(word, 47, fp) != NULL)
        {
            ++wordCounter;
            for (int i = 0; i < strlen(word); ++i)
            {
                //need to find which letter it is
                for (int j = 0; j < 27; ++j)
                {
                    if (tolower(word[i]) == key[j])
                    {
                        
                        //start my trie
                        if( (*trav).children[j] == NULL)
                        {
                            node* nw_node = malloc(sizeof(node));
                                if(nw_node == NULL)
                                {
                                    printf("Mem failure");
                                    return false;
                                }
                            (*trav).children[j] = nw_node; //cuz these are two pointers
                            trav = nw_node;
                        }
                        else
                        {
                            trav = (*trav).children[j];
                        }
                        
                    }
                
                }
            }
            
            (*trav).is_word = true;
        }
    }
    fclose(fp);
    
    if (_success)
    {
        return true;
    }
    
    else
    {
        return false;
    }
}

/**
 * Returns number of words in dictionary if loaded else 0 if not yet loaded.
 */
unsigned int size(void)
{
    
    return wordCounter;
}

/**
 * Unloads dictionary from memory. Returns true if successful else false.
 */
bool unload(void)
{
    
    for (int i = 0; i < 27; ++i)
    {
        
        if(root.children[i] != NULL)
        {
            clean( root.children[i]);
            
        }
        
    }
    
    return true;    
    
}


bool clean(node* t)
{
    bool is_done = false;
    bool _blank = false;

    
        //check to make sure all pointers are null
    
    
    for (int i = 0; i < 27; ++i) 
    {
        if ( (*t).children[i] != NULL)
        {
                clean((*t).children[i]);
                //t = (*t).children[i]; //move on down
                
        }
        
    }
    
    
    _blank = true;
    
    if (_blank)
    {

        free(t);
        is_done = true;
        
    }
    
    if (is_done)
    {
        return true;
    }
    else
    {
        return false;
    }
    
}

