PSET4 Overview:

A total of three applications for this assignment. 

1) Whodunit
-This application iterates over a image input file.  There is hidden text in the input file that is distorted by the presence of unneeded pixels.  My application runs through the input file removes the RBG triples (unneeded pixels) thus revealing the hidden text and completing the assignment. 

2) Resize
-Enlarge a 24-bit uncompressed BMP file to a factor of n

3) Recover
-Recover 'deleted' photos from a camera's disk by writing a program looking for JPEG signatures.  Once a JPEG is found write that file to disk.  