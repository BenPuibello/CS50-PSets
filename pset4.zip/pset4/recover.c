#include <cs50.h>
#include <stdio.h>
#include <stdint.h>


int main (int argc, char* argv[])
{
    uint8_t dataBuffer[512];
    
    
    if (argc != 2)
    {
        fprintf(stderr, "Usage ./recover.c input file");
        return 1;
    }
    
    char* infile = argv[1];
    
    FILE* raw = fopen(infile, "r");
    
    if (raw == NULL)
    {
        fprintf(stderr, "Can't read the infile ");
        return 2;
    }
    
    //JPEG flags
    bool _printingJPEG = false;
    bool _noImageYet = true;
    //filename
    char filename[7];
    int fileNum = 0;
    FILE* img;
    
    
    //start loop and check for EOF.
    while (fread(dataBuffer, 1, 512, raw) == 512)
    {
        //printf("%ld %ld %ld %ld\n", (long) &dataBuffer[0], (long) &dataBuffer[1], (long) &dataBuffer[2], (long) &dataBuffer[3]);
        //rintf("0x%02x\n", dataBuffer[0]);
        //check for JPEG first 4 byte
        if(_printingJPEG)
        {
            if ( dataBuffer[0] == 0xff && dataBuffer[1] == 0xd8 && dataBuffer[2] == 0xff && ( dataBuffer[3] & 0xf0) == 0xe0)
            {
                fclose(img);
                sprintf(filename, "%03i.jpg", fileNum);
                ++fileNum;
                img = fopen(filename, "w");
                fwrite(&dataBuffer, 512, 1, img);
            }
            else
            {
                fwrite(&dataBuffer, 512, 1, img);
            }
        }
        
        
        if ( (dataBuffer[0] == 0xff && dataBuffer[1] == 0xd8 && dataBuffer[2] == 0xff && ( dataBuffer[3] & 0xf0) == 0xe0) && (_noImageYet) )
        {
            
            sprintf(filename, "%03i.jpg", fileNum);
            ++fileNum;
            img = fopen(filename, "w");
            fwrite(&dataBuffer, 512, 1, img);
            _printingJPEG = true;
            _noImageYet = false;
        }
        
        

    
    }
    
    fclose(raw);
    
    
}