/**
 * Copies a BMP piece by piece, just because.
 */
       
#include <stdio.h>
#include <stdlib.h>

#include "bmp.h"

int main(int argc, char *argv[])
{
    // ensure proper usage
    if (argc != 4)
    {
        fprintf(stderr, "Usage: ./copy infile outfile\n");
        return 1;
    }

    // remember filenames
    char *infile = argv[2];
    char *outfile = argv[3];
    int n = atoi(argv[1]);

    // open input file 
    FILE *inptr = fopen(infile, "r");
    if (inptr == NULL)
    {
        fprintf(stderr, "Could not open %s.\n", infile);
        return 2;
    }

    // open output file
    FILE *outptr = fopen(outfile, "w");
    if (outptr == NULL)
    {
        fclose(inptr);
        fprintf(stderr, "Could not create %s.\n", outfile);
        return 3;
    }

    // read infile's BITMAPFILEHEADER
    BITMAPFILEHEADER bf;
    fread(&bf, sizeof(BITMAPFILEHEADER), 1, inptr);

    // read infile's BITMAPINFOHEADER
    BITMAPINFOHEADER bi;
    fread(&bi, sizeof(BITMAPINFOHEADER), 1, inptr);
    
    //store infile bi.biWidth and bi.biheight
    int32_t oldBiWidth = bi.biWidth;
    int32_t oldHeight = abs(bi.biHeight);
    
    //find the padding for infile 
    int infPadding = (4 - (bi.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;
    
    //update outfile's height and width.  Then find padding for outfile
    bi.biWidth *= n;
    bi.biHeight *= n;
    int outfPadding = (4 - (bi.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;
    bi.biSizeImage = ((sizeof(RGBTRIPLE) * bi.biWidth) + outfPadding) * abs(bi.biHeight);
    bf.bfSize = bi.biSizeImage + sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER);
    
    
    
    // ensure infile is (likely) a 24-bit uncompressed BMP 4.0
    if (bf.bfType != 0x4d42 || bf.bfOffBits != 54 || bi.biSize != 40 || 
        bi.biBitCount != 24 || bi.biCompression != 0)
    {
        fclose(outptr);
        fclose(inptr);
        fprintf(stderr, "Unsupported file format.\n");
        return 4;
    }
    
    // write outfile's BITMAPFILEHEADER
    fwrite(&bf, sizeof(BITMAPFILEHEADER), 1, outptr);

    // write outfile's BITMAPINFOHEADER
    fwrite(&bi, sizeof(BITMAPINFOHEADER), 1, outptr);
    


    // determine padding for scanlines
    //int padding = (4 - (bi.biWidth * sizeof(RGBTRIPLE)) % 4) % 4;
    
    // iterate over infile's scanlines
    for (int i = 0; i < oldHeight; i++)
    {
        
        //height
        RGBTRIPLE row_array[bi.biWidth];
        int arrayCtr = 0;
        
        //fprintf(stderr,"Original Row\n");
        // iterate over pixels in scanline of the infile
        for (int j = 0; j < oldBiWidth; j++)
        {
            // temporary storage
            RGBTRIPLE triple;

            // read RGB triple from infile
            fread(&triple, sizeof(RGBTRIPLE), 1, inptr);
            
            //resize horizontally N times
            for (int t = 0; t < n; ++t)
            {
            // write RGB triple to outfile
            fwrite(&triple, sizeof(RGBTRIPLE), 1, outptr);
            row_array[arrayCtr].rgbtBlue = triple.rgbtBlue;
            row_array[arrayCtr].rgbtGreen = triple.rgbtGreen;
            row_array[arrayCtr].rgbtRed = triple.rgbtRed;
            //printf("Ctr = %i %i %i %i\n", arrayCtr, row_array[arrayCtr].rgbtBlue, row_array[arrayCtr].rgbtGreen, row_array[arrayCtr].rgbtRed);
            ++arrayCtr;
            }
            
            
        }
        
        //write the outfiles padding
        for (int p = 0; p < outfPadding; ++p)
        {
            fputc(0x00, outptr);
        }
        
        //new row for height
        if (n > 1)
        {
            
            
            
            for (int d = 1; d < n; ++d)
            {
                //fprintf(stderr, "New row\n");
                arrayCtr = 0;
                for (int y = 0; y < bi.biWidth; ++y)
                {
                    //printf("Ctr = %i %i %i %i\n", arrayCtr, row_array[arrayCtr].rgbtBlue, row_array[arrayCtr].rgbtGreen, row_array[arrayCtr].rgbtRed);
                    fwrite(&row_array[arrayCtr], sizeof(RGBTRIPLE), 1, outptr);
                    ++arrayCtr;
                }
                
                //write new rows padding
                for (int p = 0; p < outfPadding; ++p)
                {
                    fputc(0x00, outptr);
                }
            }

        }
        
        
        // skip over padding, if any
        fseek(inptr, infPadding, SEEK_CUR);

    }

    // close infile
    fclose(inptr);

    // close outfile
    fclose(outptr);

    // success
    return 0;
}
